# YouTube-clone
This project is a clone of YouTube created entirely using HTML and CSS. The project is intended to showcase my skills in front-end web development and demonstrate my understanding of HTML and CSS. This project can serve as a useful resource for anyone looking to learn web development or improve their HTML and CSS skills.

project link: https://babunshil.github.io/YouTube-clone/
